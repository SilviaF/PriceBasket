To run this program, follow the steps below:

1- Extract the PriceBasket.zip file in a folder of your preference (e.g.: D:\workspace\PriceBasket)
2- Open a command prompt in the path where you unzipped that file.
3- Run the jar file with the following command (Windows): java -jar PriceBasket.jar list_of_products
4- The list_of_products argument should include the name of the products you buy separated by a space (e.g.: Apples Soup Bread)

Executing this program in a Windows command prompt should look like this:

java -jar PriceBasket.jar Soup Soup Bread Milk Apples

Note: DO NOT REMOVE/RENAME/MOVE THE /RESOURCES FOLDER NOR ITS CONTENT.
